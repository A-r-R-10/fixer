from setuptools import setup

setup(
    name="fixer_demo",
    version="0.1",
    description="None",
    install_requiers=["requests"],
    author_email="aliranjbar@gmail.com",
    author="alireza",
    packages=["fixer"]
)
